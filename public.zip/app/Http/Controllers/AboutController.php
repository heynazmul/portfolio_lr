<?php

namespace App\Http\Controllers;

use App\Models\About;

use Illuminate\Http\Request;

class AboutController extends Controller
{

    public function index () {
        $rows = About::get();
        return view('about.index', ['rows'=>$rows]);
    }
   public function create () {
       return view('about.create');
   }

   public function store(Request $request) {
    // 
       About::create([
           'title' => $request->title,
           'description' => $request->about
       ]);
       return redirect()->route('about');
       
   }
}
